require'nu'.setup{}
